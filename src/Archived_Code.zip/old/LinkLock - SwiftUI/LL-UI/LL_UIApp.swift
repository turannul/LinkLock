//
//  LL_UIApp.swift
//  LL-UI
//
//  Created by Turann_ on 30.03.2024.
//

import SwiftUI

@main
struct LL_UIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
